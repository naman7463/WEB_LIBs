<?php
defined('BASEPATH') OR exit('No direct script access allowed');
defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends CI_Controller {
 function __construct() 
    {
		parent::__construct();
		$this->load->helper('form');
		$this->load->helper('url');	
	   $this->load->library('form_validation');
        $this->load->model('Welcome_model');				
	}
	public function index()
	{
        if(extract($_POST)!=''){
		foreach ($_POST as $key => $value){
		$ky= $value;
	    $data[$key]=$ky;
		}
	    $id=$this->Welcome_model->res($data);
	    $config['upload_path'] = './uploads/';
        $config['allowed_types'] = '*';
        $config['max_size'] = '*';
        $config['overwrite'] = TRUE;
        $config['encrypt_name'] = FALSE;
        $config['remove_spaces'] = TRUE;
        $this->load->library('upload', $config);
        if ( ! $this->upload->do_upload('image')) {
		echo json_encode ("Insert Sucessfully");	
        }
		else{
		$imageDetailArray = $this->upload->data();
		$image =  $imageDetailArray['file_name'];
		$res=array('image'=>$image);
		$this->Welcome_model->image_update($id,$res);
		echo json_encode ("insert Sucessfully with Image");
    	}
		}
		else{
	    echo json_encode ("valid ascess");
		}
    }
	
	public function latelong()
	{
	  if(extract($_POST)!=''){	
		  $lat=$_POST['latitude'];
		  $long=$_POST['longitude'];
		  $url  = "http://maps.googleapis.com/maps/api/geocode/json?latlng=".$lat.",".$long."&sensor=false";
		  $json = @file_get_contents($url);
		  $data = json_decode($json);
		  if($data->status=="OK")
		  {
			$address = $data->results[0]->formatted_address;
			echo json_encode($address);
		  }
		  else
		  {
			echo json_encode ("No Data Found Try Again");
		  }
	  }
	  else{
		  echo json_encode ("valid ascess");
	  }
    }
	
	public function Image()
	{
        if(extract($_POST)!='')
		{
		  foreach ($_POST as $key => $value)
		  {
		    $ky= $value;
		    $data[$key]=$ky;
	      }
		  $id=$this->Welcome_model->res($data);
		  if($id!='' && !empty($_FILES['image']['name']))
		  {
			 $files = $_FILES;
		     $filesCount = count($_FILES['image']['name']);
             for($i=0; $i<$filesCount; $i++) {
             $_FILES['image']['name']= $files['image']['name'][$i];
             $_FILES['image']['type']= $files['image']['type'][$i];
             $_FILES['image']['tmp_name']= $files['image']['tmp_name'][$i];
             $_FILES['image']['error']= $files['image']['error'][$i];
             $_FILES['image']['size']= $files['image']['size'][$i];
             $config['upload_path'] = './uploads/';
             $config['allowed_types'] = '*';
             $config['max_size'] = '*';
             $config['remove_spaces'] = true;
             $config['overwrite'] = false;
             $this->load->library('upload', $config);
		     $this->upload->do_upload('image');
             $this->upload->do_upload();
             $fileName = $_FILES['image']['name'];
             $images[] = $fileName;
             }
		     $fileName = implode(',',$images);
		     $res=array('image'=>$fileName);
		     $this->Welcome_model->image_update($id,$res);
		     echo json_encode ("insert Sucessfully with Image");
		  }
		  else
		  {
		    echo json_encode ("insert Sucessfully with Image");
		  }
		}
		else
		{
	      echo json_encode ("valid ascess");
		}
    }
}
