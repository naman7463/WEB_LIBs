<?php 
class Welcome_model extends CI_Model 
{    
    function __construct()
    {
        // Call the Model constructor
        parent::__construct();
		$this->load->database();
    }
	public function res($data){
		$this->db->insert('users',$data);
		return $this->db->insert_id();
	}
	public function image_update($id,$res){
		return $this->db->update('Users', $res, array('id' =>$id ));
	}
}	